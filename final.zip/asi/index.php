<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coffee login </title>
    <script src="script.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <div class="con">
        <h1> Enter Info to sign up </h1>
        <form action="signup.php" method="POST">
		<input class="in" type="text" name="username" required placeholder="Enter first name"> <br>
        <input class="in" type="text" name="lname" required  placeholder="Enter last name"> <br>
		<input class="in" type="email" name="email" placeholder="Enter email" pattern=".*@ucp\.edu\.pk$" required  ><br>
		<input class="in" type="password" name="pass" pattern="^(?=.*\d)(?=.*[a-zA-Z]).{8,}$" required placeholder ="Enter Password" id = "password"><br>
		<input class="in" type="password" required  oninput="checkPasswordMatch()" id ="confirm-password" placeholder="ReEnter Password"><br>
        <span id="password-match-message"></span><br>
         <input id="cnic"class="in" type="cnic" pattern="^\d{5}-\d{7}-\d$" required placeholder="Enter cnic"><br>
        <input type="radio" id="male" name="gender" required value="Male">
        <label for="male">Male</label><br>
        <input type="radio" id="female" name="gender" required value="Female">
        <label for="female">Female</label><br>

           <select name="sem" id="sem">
            <option >Select current semester</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            </select>
            <br>
            <input type="checkbox" id="agree" name="agree" required value="1">
            <label for="agree" > agree with terms and conditions</label> <br>
		<input class="btn" type="submit" value="Register">
	</form>
    <a href="login.php"> Login </a>
    
    </div>

   
</body>
</html>