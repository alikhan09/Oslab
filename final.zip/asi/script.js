function checkPasswordMatch() {
    var password = document.getElementById("password");
    var confirmPassword = document.getElementById("confirm-password");
    var message = document.getElementById("password-match-message");

    if (password.value === confirmPassword.value) {
      message.textContent = "Passwords match.";
      confirmPassword.setCustomValidity("");
    } else {
      message.textContent = "Passwords do not match.";
      confirmPassword.setCustomValidity("Passwords do not match.");
    }
  }
  function cnic_chk()
  {
    var cnic= document.getElementById("cnic");
    var x = cnic.value;
    var pat = /^[0-9]{5}-[0-9]{7}-[0-9]{1}$/;
    if(!x.match(pat))
    {
        document.getElementById("cnic").style.border="2px solid red";
        chk.setCustomValidity("Cnic doesnot match the pattern");

    }
    else
    {
        document.getElementById("cnic").style.border="2px solid green";
        return true;
    }
  }