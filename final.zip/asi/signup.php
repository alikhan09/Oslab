<?php
   $name = $_POST['username'];
   $lname=$_POST['lname'];
    $email = $_POST['email'];
     $pass = $_POST['pass'];
     $gen=$_POST['gender'];
     $sem=$_POST['sem'];

       $conn = new mysqli("localhost","root","", "lp");
    $q ="insert into user (fname,lname,email,pass,gender,sem) values('".$name."','".$lname."','".$email."','".$pass."','".$gen."',".$sem.")";
     
       if ($conn->query($q) === TRUE) {
         header ("Location:login.php");
         } else {
         echo "Error deleting record: " . $conn->error;
         }
    
?>