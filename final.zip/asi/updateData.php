<?php

   $id = $_POST['id'];
   $name = $_POST['fname'];
    $email = $_POST['email'];
     $age = $_POST['sem'];
     $conn = new mysqli("localhost","root","", "lp");
     //update querry
       $sql1 = "UPDATE user SET email='".$email."' where id = ".$id."";
       $sql2 = "UPDATE user SET fname='".$name."' where id = ".$id."";
       $sql3 = "UPDATE user SET sem=".$age." where id = ".$id."";

if ($conn->query($sql1) === TRUE && $conn->query($sql2) === TRUE  && $conn->query($sql3) === TRUE) {
    header ("Location:welcome.php");
} else {
  echo "Error updating record: " . $conn->error;
}
?>