#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

int main(int argc, char *argv[]) {
    key_t key = ftok("shmfile", 65);
    int shmid = shmget(key, SHM_SIZE, 0666|IPC_CREAT);
    int *shm_ptr = (int*) shmat(shmid, 0, 0);

    // Write command line inputs to shared memory
    for (int i = 1; i < argc; i++) {
        shm_ptr[i - 1 + argc - 1] = atoi(argv[i]);
    }

    shmdt((void*) shm_ptr);
    return 0;
}
