#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

void insertionSort(int arr[], int n) {
    int i, key, j;
    for (i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;

        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

int main() {
    key_t key = ftok("shmfile", 65);
    int shmid = shmget(key, SHM_SIZE, 0666|IPC_CREAT);
    int *shm_ptr = (int*) shmat(shmid, 0, 0);

    // Count the number of elements in shared memory
    int count = 0;
    while (shm_ptr[count] != 0) {
        count++;
    }

    // Sort the numbers using insertion sort
    insertionSort(shm_ptr, count);

    // Print the sorted numbers
    printf("Numbers Sort:");
    for (int i = 0; i < count; i++) {
        printf(" %d", shm_ptr[i]);
    }
    printf("\n");

    shmdt((void*) shm_ptr);
    shmctl(shmid, IPC_RMID, NULL);
    return 0;
}
