#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>

sem_t men_sem;      // Semaphore for men
sem_t women_sem;    // Semaphore for women
sem_t count_sem;    // Semaphore for limiting the number of employees in the prayer room

int men_count = 0;  // Number of men in the prayer room
int women_count = 0; // Number of women in the prayer room

void* men(void* arg) {
    while (1) {
        sem_wait(&men_sem); // Wait for men_sem to be available
        sem_wait(&count_sem); // Wait for count_sem to be available

        if (women_count == 0) {
            men_count++; // Increment the number of men in the prayer room

            printf("A man entered the prayer room. Men count: %d\n", men_count);

            sem_post(&count_sem); // Release count_sem
            sem_post(&men_sem); // Release men_sem

            printf("men praying \n");
            sem_wait(&count_sem); // Wait for count_sem to be available
         if(men_count==3)
            {
                while(men_count)
                {
            men_count--; // Decrement the number of women in the prayer room

            printf("A man left the prayer room. men count: %d\n", men_count);

                }

            }
            sem_post(&count_sem); // Release count_sem
        } else {
            sem_post(&count_sem); // Release count_sem
            sem_post(&men_sem); // Release men_sem
            // Wait until the women leave the prayer room
        }

        // Sleep to simulate time before the next person arrives
        // ...
sleep(2);

    }
}

void* women(void* arg) {
    while (1) {
        sem_wait(&women_sem); // Wait for women_sem to be available
        sem_wait(&count_sem); // Wait for count_sem to be available

        if (men_count == 0) {
            women_count++; // Increment the number of women in the prayer room

            printf("A woman entered the prayer room. Women count: %d\n", women_count);

            sem_post(&count_sem); // Release count_sem
            sem_post(&women_sem); // Release women_sem

             printf("women praying \n");

            sem_wait(&count_sem); // Wait for count_sem to be available
            if(women_count==3)
            {
                while(women_count)
                {
            women_count--; // Decrement the number of women in the prayer room

            printf("A woman left the prayer room. Women count: %d\n", women_count);

                }

            }

            sem_post(&count_sem); // Release count_sem
        } else {
            sem_post(&count_sem); // Release count_sem
            sem_post(&women_sem); // Release women_sem
            // Wait until the men leave the prayer room
        }

        // Sleep to simulate time before the next person arrives
        sleep(2);

    }
}

int main() {
    // Initialize the semaphores
    sem_init(&men_sem, 0, 1);
    sem_init(&women_sem, 0, 1);
    sem_init(&count_sem, 0, 1);

    pthread_t men_thread, women_thread;

    // Create the men and women threads
    pthread_create(&men_thread, NULL, men, NULL);
    pthread_create(&women_thread, NULL, women, NULL);

    // Wait for the threads to finish (this code will not be reached)
    pthread_join(men_thread, NULL);
    pthread_join(women_thread, NULL);

    // Destroy the semaphores
    sem_destroy(&men_sem);
    sem_destroy(&women_sem);
    sem_destroy(&count_sem);

    return 0;
}
