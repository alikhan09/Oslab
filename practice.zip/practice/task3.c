#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>

sem_t mutex_sem;      // Mutex semaphore for mutual exclusion

int na_count = 0;     // Count of available Na atoms
int cl_count = 0;     // Count of available Cl atoms

void* NReady(void* arg) {
    sem_wait(&mutex_sem);    // Acquire mutex_sem to protect the count of Na atoms

    na_count++;             // Increment the count of Na atoms
    printf("Na atom is ready. Na count: %d\n", na_count);

    if (na_count >= 1 && cl_count >= 1) {
         printf("Salt is formed.\n");
    // Signal the presence of Cl atom
    }

    sem_post(&mutex_sem);    // Release mutex_sem


  

    pthread_exit(NULL);
}

void* CReady(void* arg) {
    sem_wait(&mutex_sem);    // Acquire mutex_sem to protect the count of Cl atoms

    cl_count++;             // Increment the count of Cl atoms
    printf("Cl atom is ready. Cl count: %d\n", cl_count);

    if (na_count >= 1 && cl_count >= 1) {
    printf("Salt is formed.\n");
  
    }

    sem_post(&mutex_sem);    // Release mutex_sem

  
    // Perform the chemical reaction (make salt)

    pthread_exit(NULL);
}

int main() {
    // Initialize the semaphores
    sem_init(&mutex_sem, 0, 1);

    pthread_t na_thread, cl_thread;

    // Create the Na and Cl threads
    pthread_create(&na_thread, NULL, NReady, NULL);
    pthread_create(&cl_thread, NULL, CReady, NULL);

    // Wait for the threads to finish
    pthread_join(na_thread, NULL);
    pthread_join(cl_thread, NULL);

    // Destroy the semaphores

    return 0;
}
