#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define MAX_PEOPLE 3

sem_t teacherSem;
sem_t studentSem;
sem_t vaccinationAreaSem;
int teacherCount = 0;
int studentCount = 0;

void *teacher(void *arg) {
    sem_wait(&teacherSem);
    printf("Teacher arrived for vaccination.\n");
    
    teacherCount++;
    printf("Teacher %d entered the vaccination area.\n", teacherCount);
    
    printf("Teacher %d got vaccinated and left the vaccination area.\n", teacherCount);
    
    
    sem_post(&teacherSem);
    
    pthread_exit(NULL);
}

void *student(void *arg) {
    sem_wait(&studentSem);
    printf("Student arrived for vaccination.\n");
    studentCount++;
    printf("Student %d entered the vaccination area.\n", studentCount);
    
    printf("Student %d got vaccinated and left the vaccination area.\n", studentCount);
    
    sem_post(&studentSem);
    
    pthread_exit(NULL);
}

int main() {
    int numTeachers, numStudents;
    printf("Enter the number of teachers: ");
    scanf("%d", &numTeachers);
    printf("Enter the number of students: ");
    scanf("%d", &numStudents);
    
    sem_init(&teacherSem, 0, 1);
    sem_init(&studentSem, 0, 1);
    sem_init(&vaccinationAreaSem, 0, MAX_PEOPLE);
    
    pthread_t teacherThreads[numTeachers];
    pthread_t studentThreads[numStudents];
    
    for (int i = 0; i < numTeachers; i++) {
        pthread_create(&teacherThreads[i], NULL, teacher, NULL);
    }
    
    for (int i = 0; i < numStudents; i++) {
        pthread_create(&studentThreads[i], NULL, student, NULL);
    }
    
    for (int i = 0; i < numTeachers; i++) {
        pthread_join(teacherThreads[i], NULL);
    }
    
    for (int i = 0; i < numStudents; i++) {
        pthread_join(studentThreads[i], NULL);
    }
    
    sem_destroy(&teacherSem);
    sem_destroy(&studentSem);
    sem_destroy(&vaccinationAreaSem);
    
    return 0;
}
